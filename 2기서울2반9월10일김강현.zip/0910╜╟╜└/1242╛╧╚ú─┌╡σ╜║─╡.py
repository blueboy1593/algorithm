import sys
sys.stdin = open("1242_input.txt", "r")

T = int(input())
for tc in range(1, T + 1):





    