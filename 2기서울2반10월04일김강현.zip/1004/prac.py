mydict = {}
mydict[(1,2)] = 1
mydict[(1,4)] = 3
# if mydict[(2, 5)] ==:
#     mydict[(2,5)] = 10
print(mydict)
print(mydict[(1,1)])